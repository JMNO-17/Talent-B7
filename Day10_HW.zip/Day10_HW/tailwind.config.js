/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./**/*.{html,js}"],
  theme: {
    extend: {
      container: {
        center: true,
        padding: '1rem',
        screens: {
          lg: '1171px',
        },
      },
      fontFamily: {
        poppins: ['Poppins'],
        lato: ['Lato'],
        dancing: ['Dancing Script'],
      },
      colors: {
        lightblue: '#D9F0FF',
        blue: '#0000FD',
        gray: '#E4E4E4',
      },
    },
  },
  plugins: [],
};
